# My python game

This is game I create a long time ago.

## Requirements

1. Python 3.5 or higher
2. Computer with Windows 7/10/11, macOS X or higher( or Linux) operating system
3. A brain
4. Monitor

## Hardware Recommendations

1. Core i3-6100 or higher
2. AMD Ryzen 3 1200 or higher
3. Basic Integrated Graphics Card
4. at least 2GB of RAM

## Python Install Guide

1. Download the latest version of python from [here](https://www.python.org/downloads/).
2. The downloading process will automatically start after clicking on installer.
3. Check if you have python installed by opening the command prompt/terminak and typing `python3 -version`(windows), `python -version`(macOS).(No idea of linux)

## How to play

1. Leftclick the 'The Orange Adventure v01.py' file
2. Select 'Open with' and select either 'Python(your version)', 'IDLE(your version)' or if you're good in coding, open with your favorite IDE/Editor/Complier then run it.
3. Enjoy and this might contain bugs and it's not finished yet.

## Details

1. You can use a similar Idea to create your own game.
2. You can upload my game (or even make it better?)but please give me a credit.